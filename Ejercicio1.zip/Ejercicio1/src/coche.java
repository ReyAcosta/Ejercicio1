public class coche {
   int numeroPuertas =2;

   public void agregaPuertas(){
       this.numeroPuertas++;
   }
}
